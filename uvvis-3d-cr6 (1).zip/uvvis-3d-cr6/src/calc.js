// Kurva kalibrasi (regresi linear) dan perhitungan mg/kg Cr(VI)
const STD=[[0,0.002],[0.1,0.077],[0.2,0.151],[0.4,0.305],[0.6,0.452],[0.8,0.606]];
const tb=document.querySelector('#std tbody');
STD.forEach(([c,a],i)=>{const r=tb.insertRow();
  r.innerHTML=`<td><input type="number" step="0.01" value="${c}" data-i="${i}" data-k="0"></td><td><input type="number" step="0.001" value="${a}" data-i="${i}" data-k="1"></td>`;});
tb.oninput=e=>{STD[e.target.dataset.i][e.target.dataset.k]=parseFloat(e.target.value)||0;drawCal()};
['as','m','ve','fp'].forEach(id=>document.getElementById(id).oninput=drawCal);
function regress(p){const n=p.length,sx=p.reduce((s,q)=>s+q[0],0),sy=p.reduce((s,q)=>s+q[1],0);
  const sxx=p.reduce((s,q)=>s+q[0]*q[0],0),sxy=p.reduce((s,q)=>s+q[0]*q[1],0),syy=p.reduce((s,q)=>s+q[1]*q[1],0);
  const m=(n*sxy-sx*sy)/(n*sxx-sx*sx),b=(sy-m*sx)/n;
  const r=(n*sxy-sx*sy)/Math.sqrt((n*sxx-sx*sx)*(n*syy-sy*sy));return{m,b,r2:r*r};}
function drawCal(){
  const {m,b,r2}=regress(STD),cs=document.getElementById('cal'),g=cs.getContext('2d');
  const css=getComputedStyle(document.body),ink=css.color,acc='#7a2f8f';
  g.clearRect(0,0,cs.width,cs.height);
  const W=cs.width,H=cs.height,L=44,B=30,xmax=Math.max(...STD.map(s=>s[0]),.1)*1.1,ymax=Math.max(...STD.map(s=>s[1]),.1)*1.15;
  const X=x=>L+x/xmax*(W-L-12),Y=y=>H-B-y/ymax*(H-B-14);
  g.strokeStyle=ink;g.fillStyle=ink;g.globalAlpha=.6;g.beginPath();g.moveTo(L,10);g.lineTo(L,H-B);g.lineTo(W-8,H-B);g.stroke();g.globalAlpha=1;
  g.font='11px sans-serif';g.fillText('C (mg/L)',W/2-20,H-8);g.fillText('A',8,16);
  g.strokeStyle=acc;g.lineWidth=2;g.beginPath();g.moveTo(X(0),Y(b));g.lineTo(X(xmax),Y(m*xmax+b));g.stroke();
  g.fillStyle=acc;STD.forEach(([x,y])=>{g.beginPath();g.arc(X(x),Y(y),4,0,7);g.fill()});
  const As=parseFloat(document.getElementById('as').value)||0,
    mass=parseFloat(document.getElementById('m').value),V=parseFloat(document.getElementById('ve').value),
    fp=parseFloat(document.getElementById('fp').value)||1,C=(As-b)/m;
  const x=Math.max(0,C);g.strokeStyle='#d98a00';g.setLineDash([4,3]);g.lineWidth=1;
  g.beginPath();g.moveTo(X(0),Y(As));g.lineTo(X(x),Y(As));g.lineTo(X(x),H-B);g.stroke();g.setLineDash([]);
  const mgkg=C*fp*V/mass; // mg/L × L / kg = mg/kg  (mL/g)
  const flag=mgkg<3?'di bawah batas 3 mg/kg':'MELEBIHI batas 3 mg/kg';
  document.getElementById('res').innerHTML=
   `y = ${m.toFixed(4)}x ${b<0?'−':'+'} ${Math.abs(b).toFixed(4)} &nbsp; R² = ${r2.toFixed(4)}`+
   `<br>C ekstrak = <b>${C.toFixed(3)}</b> mg/L`+
   `<br>Cr(VI) = C × fp × V / m = <b>${isFinite(mgkg)?mgkg.toFixed(2):'–'} mg/kg</b> (${flag})`+
   (r2<.995?'<br><i>R² &lt; 0,995: periksa standar kalibrasi.</i>':'');
}
drawCal();
