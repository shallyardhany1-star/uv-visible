// Model 3D bagan spektrofotometer UV-Vis (berkas tunggal / single beam)
const cv=document.getElementById('c'),stage=document.getElementById('stage');
const renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
const scene=new THREE.Scene(),cam=new THREE.PerspectiveCamera(40,1,.1,100);
scene.add(new THREE.AmbientLight(0xffffff,.7));
const dl=new THREE.DirectionalLight(0xffffff,.8);dl.position.set(4,8,6);scene.add(dl);
const floor=new THREE.Mesh(new THREE.PlaneGeometry(40,12),new THREE.MeshStandardMaterial({color:0x1b2733}));
floor.rotation.x=-Math.PI/2;floor.position.y=-1;scene.add(floor);

const parts={};
const std=(c,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:.5,metalness:.2},o));
function add(id,name,desc,mesh,x,labelY=1.2){
  mesh.position.x=x;mesh.userData.id=id;scene.add(mesh);
  parts[id]={name,desc,mesh,x,labelY,mat:mesh.material};
}
// 1 Sumber cahaya
const lamp=new THREE.Mesh(new THREE.SphereGeometry(.45,24,24),std(0xffd35a,{emissive:0xffaa00,emissiveIntensity:.8}));
add('lamp','Sumber cahaya','Lampu deuterium (UV, 190–350 nm) dan tungsten/halogen (tampak, 350–900 nm) menghasilkan cahaya polikromatik. Lampu dipindah otomatis pada ±340–350 nm.',lamp,-7);
// 2 Monokromator (celah + kisi)
const mono=new THREE.Mesh(new THREE.BoxGeometry(2.2,1.6,1.6),std(0x3b4b5c,{transparent:true,opacity:.75}));
add('mono','Monokromator','Celah masuk, kisi difraksi dan celah keluar memilih satu panjang gelombang sempit (λ) dari cahaya polikromatik. Kisi diputar untuk memindai λ.',mono,-3.8);
const grating=new THREE.Mesh(new THREE.CylinderGeometry(.35,.35,.1,32),std(0xc0c8d0,{metalness:.9,roughness:.2}));
grating.rotation.z=Math.PI/2;grating.rotation.y=.5;grating.position.set(-3.8,0,0);scene.add(grating);
// 3 Kuvet
const cuv=new THREE.Mesh(new THREE.BoxGeometry(.9,1.3,.9),std(0xffffff,{transparent:true,opacity:.28,roughness:.1}));
add('cuv','Kuvet sampel','Wadah larutan berlebar b = 1 cm. Kuarsa untuk UV, kaca/plastik untuk tampak. Berisi larutan Cr(VI)–DPC berwarna ungu. Blanko (reagen tanpa analit) dipakai untuk nol absorbansi.',cuv,0);
const liquid=new THREE.Mesh(new THREE.BoxGeometry(.8,.85,.8),std(0x7a2f8f,{transparent:true,opacity:.7}));
liquid.position.set(0,-.2,0);scene.add(liquid);
// 4 Detektor
const det=new THREE.Mesh(new THREE.BoxGeometry(1.2,1.2,1.2),std(0x2f6f5e));
add('det','Detektor','Fotodioda / tabung pengganda foton (PMT) mengubah intensitas cahaya yang diteruskan (I) menjadi sinyal listrik. Dibandingkan dengan I0 blanko untuk memperoleh T.',det,3.6);
// 5 Pembaca
const disp=new THREE.Mesh(new THREE.BoxGeometry(1.8,1.3,.4),std(0x222b34));
disp.position.set(0,0,-2.4);
add('disp','Pembaca data','Komputer/layar menghitung T = I/I0 dan A = −log T, lalu menampilkan A, kurva kalibrasi dan konsentrasi.',disp,6.8);
disp.position.z=-1.8;
const scr=new THREE.Mesh(new THREE.PlaneGeometry(1.5,.9),new THREE.MeshBasicMaterial({color:0x7cf0c0}));
scr.position.set(6.8,0,-1.58);scene.add(scr);

// Berkas cahaya
function beam(x1,x2){const g=new THREE.CylinderGeometry(.08,.08,x2-x1,12);
  const m=new THREE.Mesh(g,new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.85}));
  m.rotation.z=Math.PI/2;m.position.x=(x1+x2)/2;scene.add(m);return m;}
const b1=beam(-6.55,-4.9),b2=beam(-2.7,-.45),b3=beam(.45,3);
b1.material.color.set(0xfff2c0);[b1,b2,b3].forEach(b=>b.material.opacity=.18);

// Wavelength -> RGB
function wl2rgb(w){let r=0,g=0,b=0;
  if(w<440){r=-(w-440)/60;b=1}else if(w<490){g=(w-440)/50;b=1}else if(w<510){g=1;b=-(w-510)/20}
  else if(w<580){r=(w-510)/70;g=1}else if(w<645){r=1;g=-(w-645)/65}else r=1;
  let f=w<420?.3+.7*(w-380)/40:w>700?.3+.7*(780-w)/80:1;if(w<380)f=.3;
  return new THREE.Color(Math.pow(r*f,.8),Math.pow(g*f,.8),Math.pow(b*f,.8));}
window.UV={
  absorb(w,c){return .75*c*Math.exp(-Math.pow((w-540)/55,2));},
  update(w,c){
    const A=UV.absorb(w,c),T=Math.pow(10,-A),col=wl2rgb(w);
    b2.material.color.copy(col);b3.material.color.copy(col);
    b3.material.opacity=.04+.2*T;UV.T=T;UV.w=w;
    // warna larutan ~ komplementer visual: makin pekat makin ungu
    liquid.material.opacity=.15+.6*Math.min(1,c/1.2);
    const set=(id,v)=>document.getElementById(id).textContent=v;
    set('wlv',w);set('cv',c.toFixed(2));set('av',A.toFixed(3));set('tv',(T*100).toFixed(1));
  }};
const $=id=>document.getElementById(id),wlI=$('wl'),ccI=$('cc');
const upd=()=>UV.update(+wlI.value,+ccI.value);wlI.oninput=ccI.oninput=upd;upd();


// ===== Foton: polikromatis -> monokromatis =====
const NP=150,pp=[],pos=new Float32Array(NP*3),col=new Float32Array(NP*3);
const pg=new THREE.BufferGeometry();
pg.setAttribute('position',new THREE.BufferAttribute(pos,3));pg.setAttribute('color',new THREE.BufferAttribute(col,3));
const pts=new THREE.Points(pg,new THREE.PointsMaterial({size:.26,vertexColors:true,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));
pts.frustumCulled=false;scene.add(pts);
function spawn(p,first){
  const sel=UV.w||540;
  p.w=Math.random()<.3?sel+(Math.random()-.5)*30:380+Math.random()*400; // sebagian dekat λ terpilih agar terlihat
  p.c=wl2rgb(p.w);p.x=-6.5-(first?Math.random()*9:0);p.jy=(Math.random()-.5)*.25;p.jz=(Math.random()-.5)*.25;
  p.v=.035+Math.random()*.012;p.f=1;p.state=0;p.y=p.jy;
}
for(let i=0;i<NP;i++){const p={};spawn(p,true);pp.push(p);}
function stepPhotons(){
  const sel=UV.w||540,T=UV.T===undefined?1:UV.T,selC=wl2rgb(sel);
  pp.forEach((p,i)=>{
    p.x+=p.state===2?p.v*.15:p.v;
    const d=(p.w-580)/200*.7;let c=p.c,y=p.jy;
    if(p.x>=-4.9&&p.x<-3.8){y=p.jy*.3+d*(p.x+4.9)/1.1;}                     // kisi menguraikan cahaya
    if(p.x>=-3.8&&p.state===0){p.state=Math.abs(p.w-sel)<=15?1:2;}            // celah keluar: lolos atau tertahan
    if(p.state===1){const k=Math.max(0,Math.min(1,(p.x+3.8)/1.1));y=d*(1-k);if(p.x>-3.0)c=selC;}
    if(p.state===2){y=d;p.f-=.035;}
    if(p.state===1&&p.x>=-.45&&!p.chk){p.chk=1;if(Math.random()>T)p.state=3;}   // diserap larutan (A)
    if(p.state===3){y=0;p.f-=.08;}
    if(p.f<=0||p.x>3){spawn(p);p.chk=0;c=p.c;p.f=0;}
    const vis=p.x>-6.5&&p.f>0&&document.getElementById('ph').checked?p.f:0;
    pos[i*3]=p.x;pos[i*3+1]=y;pos[i*3+2]=p.jz;
    col[i*3]=c.r*vis;col[i*3+1]=c.g*vis;col[i*3+2]=c.b*vis;
  });
  pg.attributes.position.needsUpdate=pg.attributes.color.needsUpdate=true;
}

// Label + chips
const labs=$('labels');
Object.entries(parts).forEach(([id,p])=>{
  const d=document.createElement('div');d.className='lb';d.textContent=p.name;labs.appendChild(d);p.lab=d;
  const c=document.createElement('button');c.className='chip';c.textContent=p.name;c.onclick=()=>pick(id);$('chips').appendChild(c);p.chip=c;
});
let cur=null;
function pick(id){cur=id;
  Object.entries(parts).forEach(([k,p])=>{const on=k===id;p.chip.classList.toggle('on',on);
    if(p.mat.emissive&&k!=='lamp')p.mat.emissive.set(on?0x555555:0x000000);});
  $('info').innerHTML=`<h2>${parts[id].name}</h2><p>${parts[id].desc}</p>`;}

// Orbit manual + klik
let th=.5,ph=.35,rad=17,drag=false,lx=0,ly=0,moved=0;
cv.onpointerdown=e=>{drag=true;lx=e.clientX;ly=e.clientY;moved=0;cv.setPointerCapture(e.pointerId)};
cv.onpointermove=e=>{if(!drag)return;th-=(e.clientX-lx)*.006;ph=Math.max(-.2,Math.min(1.4,ph+(e.clientY-ly)*.006));moved+=Math.abs(e.clientX-lx)+Math.abs(e.clientY-ly);lx=e.clientX;ly=e.clientY};
cv.onpointerup=e=>{drag=false;if(moved<5){const r=cv.getBoundingClientRect(),ray=new THREE.Raycaster();
  ray.setFromCamera(new THREE.Vector2((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1),cam);
  const h=ray.intersectObjects(Object.values(parts).map(p=>p.mesh))[0];if(h)pick(h.object.userData.id);}};
cv.onwheel=e=>{e.preventDefault();rad=Math.max(7,Math.min(30,rad+e.deltaY*.01))};
function resize(){const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();}
addEventListener('resize',resize);resize();
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
(function loop(){requestAnimationFrame(loop);
  if(!drag&&!reduce)th+=.0012;
  cam.position.set(Math.sin(th)*Math.cos(ph)*rad,Math.sin(ph)*rad,Math.cos(th)*Math.cos(ph)*rad);cam.lookAt(0,0,0);
  stepPhotons();
  grating.rotation.y=.5+Math.sin(Date.now()/1500)*.15;
  const v=new THREE.Vector3(),w=stage.clientWidth,h=stage.clientHeight;
  Object.values(parts).forEach(p=>{v.set(p.x,p.labelY,0).project(cam);
    p.lab.style.left=(v.x*.5+.5)*w+'px';p.lab.style.top=(-v.y*.5+.5)*h+'px';});
  renderer.render(scene,cam);})();

// Tab
document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{
  document.querySelectorAll('.tab,.pane').forEach(e=>e.classList.remove('on'));
  t.classList.add('on');$(t.dataset.t).classList.add('on');if(t.dataset.t==='hitung')window.drawCal&&drawCal();});
